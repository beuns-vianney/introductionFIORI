/* global QUnit */

sap.ui.require(["introtofiori/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
